//PascalCasing
function Message() {
    return <h1>Hello world</h1>;
}

export default Message;